import jwt from 'jsonwebtoken';
import dbConnection from '../config/connectionMySQL.js'

const _checkToken = async (req, res, next) => {
    // creo esta propiedad session que va a estar dentro de la request para poder
    // ser accedida en procesos posteriores, reseteada ({user : null});
    req.session = { user: null };

    // trato de obtener los tokens de las cookies
    const accessToken = req.cookies.access_token;
    const refreshToken = req.cookies.refresh_token;
    console.log(accessToken, refreshToken)

    // si no hay accessToken continua con el siguiente proceso.
    if (!accessToken) {
        // console.log('No hay access_token')
        return next();
    }

    try {
        // intento verificar el token, obtengo la info del payload, finalmente 
        // continuo ya que se verifica correctamente el accessToken.
        const data = jwt.verify(accessToken, process.env.JWT_SECRET);
        req.session.user = data;
        // console.log('NO HAY ACCESTOKEN←←')
        return next();

    } catch (error) {
        // en el caso de que no haya accesstToken o esté expirado verifico que 
        // haya un refreshToken. Si no hay, continuo. No se pud overificar el usuario.

        if (!refreshToken) {
            // console.log('No hay refresh_token')
            return next();
        }

        try {

            // Si hay refreshToken, intento verificarlo para recuperar el payload (info del usuario)
            const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

            // recupero el payload, entonces intento recuperar informacion desde la DB usando el 
            // refreshToken que vino en la cookie inicialmente.
            const [data] = await dbConnection.query(
                `SELECT * FROM refresh_tokens WHERE token = ?`,
                [refreshToken]
            );

            // si no hay usuarios que coincidan con el token que llego en la cookie continuo al 
            // siguente proceso.
            if (data.length === 0) return next();

            // Si el refreshToken es válido y se encontró el resultado buscado en la DB, creo un nuevo 
            // accessToken

            const newAccessToken = jwt.sign(
                { email: payload.email },
                process.env.JWT_SECRET,
                { expiresIn: '15m' }
            );

            res.cookie('access_token', newAccessToken,
                {
                    httpOnly: true,
                    secure: process.env.NODE_ENV === 'production',
                    sameSite: 'strict',
                    maxAge: 1000 * 60 * 15
                }
            );

            req.session.user = { email: payload.email }

        } catch { }
    }

    next();
}


const checkToken = async (req, res, next) => {
    req.session = { user: null };

    const accessToken = req.cookies.access_token;
    const refreshToken = req.cookies.refresh_token;

    // si hay accesstoken, verifico si es correcto.
    if (accessToken) {

        try {
            const data = jwt.verify(accessToken, process.env.JWT_SECRET);
            req.session.user = data;
            return next();
        } catch (error) {
            // no se pudo validar, asi que continúo 
            console.log("access_token inválido o expirado")
        }
    }

    // si no hay accessToken y tampco hay refreshToken, salgo porque no hay sesión.
    if (!refreshToken) {
        return next();
    }

    // si hay refreshToken, intentamos validarlo. 
    try {
        const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

        const [rows] = await dbConnection.query(
            'SELECT * FROM refresh_tokens WHERE token = ?',
            [refreshToken]
        );

        // si no hay resultados en la query mysql salgo, significa que el refreshToken
        // no se puede validar con los que estan almacenados en la DB.
        if (rows.length == 0) return next();

        // si encontró coincidencias en la DB significa que el refreshToken es correcto,
        // entocnes creamos un nuevo accessToken.

        const newAccessToken = jwt.sign(
            {email : payload.email},
            process.env.JWT_SECRET,
            {expiresIn : '15m'}
        );

        res.cookie('access_token', newAccessToken, {
            httpOnly: true,
            secure : process.env.NODE_ENV == 'production',
            sameSite : 'strict',
            maxAge : 1000 * 60 * 15
        });

        req.session.user = { email : payload.email }
        return next();


    } catch (error) {
        console.log("error al verificar el refresh token o crear el nuevo access_token")
         return next();
    }

}

export default checkToken;
