import { Router } from 'express';
import { getAll, registerUser, loginUser, enterProtected, logoutUser } from '../controllers/user.controller.js'

// esto es para el front
// import refreshAccessToken from '../controllers/refreshAccessToken.controller.js';
// router.post('/refresh', refreshAccessToken)

const router = Router();

router.get('/getAll', getAll);

router.post('/register', registerUser)
router.post('/login', loginUser);
router.post('/logout', logoutUser);


router.get('/protected', enterProtected)



export default router;
